<?php 
 
// include template file (header.php)

 require_once('templates/header.php');


?>

<div class="container"><br><br><br>

	<div class="row">

		   <!-- Require the content php file -->

       <?php require_once('content.php'); ?> 
        
</div></div><br><br>


<?php

// include template file (footer.php)

 require_once('templates/footer.php');

?>